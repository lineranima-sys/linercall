# LinerCall's — Community Hub

Projeto inicial do LinerCall's com interface responsiva, autenticação Google, chat em tempo real, lista de membros, ranking, desafios PvP e salas de voz/vídeo/tela.

## O que já está preparado

- Interface inspirada na referência enviada: fundo azul-marinho em pixel grid, ciano, detalhes dourados e cartões escuros.
- Login Google via Firebase Authentication; o app aceita apenas endereços `@gmail.com`.
- Código de convite validado por Cloud Function (não fica exposto no JavaScript do site).
- Chat e ranking em tempo real com Cloud Firestore.
- Presença aproximada de membros online (últimos 3 minutos).
- Desafios de dados com convite, aceite/recusa e resultado calculado no servidor.
- Salas Jitsi com áudio, vídeo e compartilhamento de tela pelos controles da chamada.
- Dois minigames locais: Dados do caos e Teste de reflexo.

## 1. Criar e configurar o Firebase

1. Acesse https://console.firebase.google.com/ e crie um projeto chamado `linercalls` (ou outro nome).
2. Adicione um app Web e copie a configuração para `firebase-config.js`.
3. Em Authentication > Sign-in method, ative **Google**.
4. Em Authentication > Settings > Authorized domains, adicione seu domínio Vercel e o domínio de preview que você realmente usar.
5. Em Firestore Database, crie o banco em modo produção.
6. Instale a Firebase CLI no computador: `npm install -g firebase-tools`.
7. Faça login: `firebase login` e selecione o projeto: `firebase use --add`.

## 2. Definir o código privado

Na pasta do projeto, rode:

```bash
firebase functions:secrets:set LINERCALLS_INVITE_CODE
```

Digite o código de convite quando a CLI pedir. Não coloque esse código em `app.js`, `firebase-config.js`, GitHub ou Vercel.

## 3. Publicar as regras e funções

Na raiz do projeto:

```bash
npm install -g firebase-tools
cd functions
npm install
cd ..
firebase deploy --only firestore:rules,functions
```

As Cloud Functions podem exigir que o projeto esteja no plano Blaze e que o faturamento esteja configurado. Confira os custos e limites no Firebase antes de ativar.

## 4. Publicar no GitHub + Vercel

1. Envie os arquivos da pasta para um repositório GitHub.
2. Na Vercel, importe o repositório.
3. Framework Preset: **Other**. Build Command: vazio. Output Directory: `.`.
4. Faça o deploy. Depois adicione o domínio Vercel em Firebase Authentication > Authorized domains.

## 5. Calls e compartilhamento de tela

As salas usam a infraestrutura pública do Jitsi Meet (`meet.jit.si`). Dentro da call, cada pessoa pode habilitar microfone/câmera e usar o botão de compartilhar tela. O navegador precisa de permissão e HTTPS. Como a sala usa um provedor público, ela não é uma infraestrutura privada hospedada por você; para produção com controle total, será necessário hospedar/configurar seu próprio servidor Jitsi ou outro serviço de mídia.

## Limites importantes desta primeira versão

- Os minigames Dados do caos e Teste de reflexo são locais. O PvP online é o duelo de dados com convite e resultado no servidor.
- A presença online é aproximada por atualização de horário, não é um indicador infalível de conexão.
- O código de convite é compartilhado por todos os membros. Para revogar o acesso, troque o Secret e publique novamente a função.
- Não existe recuperação de conta/senha própria: o acesso é gerenciado pelo Google.
- Antes de abrir para muita gente, configure App Check, limites anti-spam para chat/desafios, moderação e política de privacidade.
