const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const crypto = require('crypto');
initializeApp();
const db = getFirestore();
const inviteCode = defineSecret('LINERCALLS_INVITE_CODE');

function requireGmail(request) {
  if (!request.auth || !request.auth.token.email || !request.auth.token.email.toLowerCase().endsWith('@gmail.com')) {
    throw new HttpsError('unauthenticated', 'Entre com uma conta Google @gmail.com.');
  }
}

exports.validateInviteCode = onCall({ secrets: [inviteCode], maxInstances: 5 }, async (request) => {
  const submitted = String(request.data?.code || '');
  const expected = inviteCode.value();
  const a = Buffer.from(crypto.createHash('sha256').update(submitted).digest('hex'));
  const b = Buffer.from(crypto.createHash('sha256').update(expected).digest('hex'));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new HttpsError('permission-denied', 'Código de acesso incorreto.');
  return { valid: true };
});

exports.acceptChallenge = onCall({ maxInstances: 10 }, async (request) => {
  requireGmail(request);
  const uid = request.auth.uid;
  const id = String(request.data?.challengeId || '');
  if (!id) throw new HttpsError('invalid-argument', 'Desafio inválido.');
  const ref = db.collection('challenges').doc(id);
  const result = await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError('not-found', 'Desafio não encontrado.');
    const c = snap.data();
    if (c.toUid !== uid) throw new HttpsError('permission-denied', 'Esse desafio não é seu.');
    if (c.status !== 'pending') throw new HttpsError('failed-precondition', 'Esse desafio já foi respondido.');
    const fromRef = db.collection('users').doc(c.fromUid);
    const toRef = db.collection('users').doc(c.toUid);
    const fromSnap = await tx.get(fromRef); const toSnap = await tx.get(toRef);
    if (!fromSnap.exists || !toSnap.exists) throw new HttpsError('not-found', 'Jogador não encontrado.');
    const rollFrom = crypto.randomInt(1, 21); const rollTo = crypto.randomInt(1, 21);
    const tie = rollFrom === rollTo;
    const winnerUid = tie ? null : (rollFrom > rollTo ? c.fromUid : c.toUid);
    if (!tie) {
      const winnerRef = winnerUid === c.fromUid ? fromRef : toRef;
      const loserRef = winnerUid === c.fromUid ? toRef : fromRef;
      tx.update(winnerRef, { wins: FieldValue.increment(1) });
      tx.update(loserRef, { losses: FieldValue.increment(1) });
    }
    const resultText = tie ? `Empate (${rollFrom} × ${rollTo})` : `${winnerUid === c.fromUid ? c.fromName : c.toName} venceu (${rollFrom} × ${rollTo})`;
    tx.update(ref, { status: 'done', rollFrom, rollTo, winnerUid, resultText, resolvedAt: FieldValue.serverTimestamp() });
    return { message: resultText };
  });
  return result;
});

exports.declineChallenge = onCall({ maxInstances: 10 }, async (request) => {
  requireGmail(request);
  const id = String(request.data?.challengeId || '');
  const ref = db.collection('challenges').doc(id);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError('not-found', 'Desafio não encontrado.');
    const c = snap.data();
    if (c.toUid !== request.auth.uid) throw new HttpsError('permission-denied', 'Esse desafio não é seu.');
    if (c.status !== 'pending') throw new HttpsError('failed-precondition', 'Esse desafio já foi respondido.');
    tx.update(ref, { status: 'declined', resolvedAt: FieldValue.serverTimestamp() });
  });
  return { ok: true };
});
